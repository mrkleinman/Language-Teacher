// probe: is a FROZEN Listening target set feasible regardless of the attempt seed (the clock)?
const { setup } = require('./tests14')
const lang = process.argv[2] || 'th', N = +(process.argv[3] || 30)
const S = setup(lang), c = S.c; const ids = new Set(S.targets.map(t => t.id))
S.vocab.forEach(w => { if (ids.has(w.id)) { w.dueDate = '2026-01-01'; w.difficulty = 'hard' } else { w.dueDate = '2099-01-01'; if (w.difficulty === 'hard') w.difficulty = 'medium' } })
let ok = 0; const t0 = Date.now(); const turns = []
for (let i = 0; i < N; i++) {
  const seed = (process.env.SP || 'lattempt-2026-10-08T05:') + String(10 + i % 50).padStart(2, '0') + ':' + String((i * 7) % 60).padStart(2, '0') + '.' + (100 + i * 13) + 'Z'
  const f = c.selectFeasibleListeningTargets({ lang, vocab: S.vocab, pool: S.targets, need: 30, seed, frozen: true })
  if (f.feasible) ok++
  turns.push((f.plan && f.plan.meaningPlan ? f.plan.meaningPlan.turnCount : '?') + (f.feasible ? '' : '✗') + (f.plan && f.plan.seedUsed ? '' : ''))
}
console.log(lang + ' frozen feasible ' + ok + '/' + N + ' · turns ' + turns.join(' ') + ' · ' + Math.round((Date.now() - t0) / N) + ' ms/plan')
