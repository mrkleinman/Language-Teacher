// probe: tests23 J — does a rebuild prompt contain a line of the failed track? over many seed pairs
const { setup, mock } = require('./tests14')
const lang = process.argv[2] || 'zh', N = +(process.argv[3] || 12)
const lineText = l => l.thai || l.japanese || l.chinese || ''
;(async () => {
  const S = setup(lang); const ids = new Set(S.targets.map(t => t.id))
  S.vocab.forEach(w => { if (ids.has(w.id)) { w.dueDate = '2026-01-01'; w.difficulty = 'hard' } else { w.dueDate = '2099-01-01'; if (w.difficulty === 'hard') w.difficulty = 'medium' } })
  const miss = S.targets[0].id
  const run = async (ln, extra) => { mock(S, lang, { ln }); const inner = S._mockFn, prompts = []
    S.c.mockGeminiGenerate = async (k, m, msgs, max, o) => { prompts.push(msgs[msgs.length - 1].content); return inner(k, m, msgs, max, o) }
    const logs = []; const r = await S.c.buildStandaloneListeningTrack({ lang, vocab: S.vocab, apiKey: 'AIzaSyTEST-harness-key-000000', model: S.c.ev('GEMINI_DEFAULT_MODEL'), onLog: m => logs.push(m), ...extra }); return { ...r, prompts, logs } }
  let bad = 0
  for (let i = +(process.env.I0 || 0); i < N; i++) {
    const sA = 'lattempt-2026-10-08T04:28:' + String(i).padStart(2, '0') + '.' + (100 + i * 41) + 'Z', sB = sA.replace(/\.(\d+)Z/, (m, d) => '.' + (+d + 7 + i) + 'Z')
    const rE = await run({ missing: [miss], noRepair: true }, { attemptId: sA })
    const rJ = await run({}, { attemptId: sB, targetIds: rE.track.selectedTargetIds.slice(), rebuildOf: rE.track.id })
    const p = rJ.prompts.find(q => /LISTENING conversation/.test(q)) || ''
    const hit = (rE.track.listening?.lines || []).filter(l => p.includes(lineText(l))).map(lineText)
    if (hit.length || rJ.track.status !== 'READY') bad++
    if (hit.length) { const k = p.indexOf(hit[0]); console.log('   CTX: ' + p.slice(Math.max(0, k - 300), k + 60).replace(/\n/g, ' ⏎ ')) }
    console.log(i, rE.track.status, rJ.track.status, 'reused=' + JSON.stringify(hit))
  }
  console.log('bad ' + bad + '/' + N)
})()
