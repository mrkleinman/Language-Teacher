// v674 — deterministic replay of the LIVE 8-Oct Listening target sets (TH listening-log-2026-10-08T01-08-11 · JA
// listening-log-2026-10-08T01-05-53 · ZH listening-log-2026-10-08T01-06-43) through the v674 VERBALIZABILITY-FIRST
// planner: language adapter blueprints → feasibility (defer / infeasible) → the meaning plan with a proven frame on every
// target turn. No model call. The learner inventory is RECONSTRUCTED from the log (introducedContent / authorised counts
// and the bank order) — an approximation of the live learner, stated in the output.
const { setup } = require('./tests14')
const fs = require('fs')
const [, , LOG, LANG] = process.argv
const S = setup(LANG), c = S.c
const txt = fs.readFileSync(LOG, 'utf8')
const ids = JSON.parse((txt.match(/LISTENING_SELECTED_TARGET_IDS=(\[[^\]]*\])/) || [])[1] || '[]')
const introduced = +((txt.match(/LEARNER_INVENTORY language=\w+ introducedContent=(\d+)/) || [])[1] || 0)
const belt = (txt.match(/LEVEL belt=([^ ]+(?: Kyu)?) /) || [])[1] || '10th Kyu'
c.setLearnerStateOverride({ rank: belt, source: 'replay' })
// reconstruct: the targets + the first `introduced` other words in curriculum order are taught; everything else is new
const order = S.vocab.slice().sort((a, b) => (a.curriculumIndex || a.unlockOrder || a.id) - (b.curriculumIndex || b.unlockOrder || b.id))
const idSet = new Set(ids)
const taught = new Set(order.filter(w => !idSet.has(w.id)).slice(0, introduced).map(w => w.id))
S.vocab.forEach(w => {
  if (idSet.has(w.id) || taught.has(w.id)) { w.status = 'learning'; w.lastSeen = '2026-10-01'; w.repCount = Math.max(1, w.repCount || 1); w.dueDate = idSet.has(w.id) ? '2026-10-01' : '2099-01-01' }
  else { w.status = 'new'; w.lastSeen = null; w.repCount = 0; w.interval = 0; w.dueDate = null; delete w.introducedAt; w.manualKnown = false }
})
const surf = w => LANG === 'ja' ? w.japanese : LANG === 'zh' ? w.chinese : w.thai
const words = ids.map(id => S.vocab.find(w => w.id === id)).filter(Boolean)
console.log('v674 VERBALIZABILITY-FIRST replay (' + LANG + ') — live 8-Oct target set: ' + words.length + ' targets · belt ' + belt + ' · learner inventory reconstructed: ' + introduced + ' taught words + the 30 targets (bank order; approximation of the live learner)')
console.log('TARGETS: ' + words.map(w => surf(w) + ' "' + String(w.english || '').split(/[;/]/)[0] + '"').join(' · '))
const t0 = Date.now()
// 1. as a FROZEN set (no substitution): which live targets have NO proven realisation?
const fz = c.selectFeasibleListeningTargets({ lang: LANG, vocab: S.vocab, pool: words, need: words.length, seed: 'replay-v674', frozen: true })
console.log('\n1) FROZEN SET (no substitution): feasible=' + fz.feasible + (fz.reason ? ' · ' + fz.reason.slice(0, 300) : ''))
const unv = (fz.plan && fz.plan.unverbalizable) || []
console.log('   unverbalizable with this learner\'s words: ' + (unv.length ? unv.map(u => u.surface + ' (' + u.why + ')').join(' · ') : 'none'))
// 2. as a NEW track: the SRS pool (live targets first, then the rest of the learner's due / learned words) — deferral
const pool = words.concat(S.vocab.filter(w => taught.has(w.id)))
const f = c.selectFeasibleListeningTargets({ lang: LANG, vocab: S.vocab, pool, need: 30, seed: 'replay-v674' })
console.log('\n2) NEW TRACK from the same SRS order: ' + c.listeningFeasibilityLog(f, LANG).join('\n   '))
const plan = f.plan, byId = new Map((plan ? plan.scenes : []).flatMap(sc => sc.skeleton).map(k => [k.turn, k]))
if (plan) {
  console.log('\nSTORY: ' + plan.story.join(' → ') + ' · ' + plan.meaningPlan.turnCount + ' planned turns · ' + plan.provenTurns + ' proven turn(s) · meaning plan ' + (plan.meaningPlan.valid ? 'VALID' : 'INVALID'))
  plan.scenes.forEach(sc => { console.log('  ' + sc.sceneId + ' [' + sc.phase + ']')
    sc.skeleton.forEach(k => console.log('     ' + k.speaker + ' ' + k.intent + (k.slot && k.intent === 'QUESTION' ? '(' + k.slot + ')' : '') + (k.targetIds.length ? ' [' + k.surfaces.join('+') + ']' : '') + '  ⟦' + (k.frame || '—') + '⟧')) })
  const frames = plan.scenes.flatMap(sc => sc.skeleton.map(k => k.frame || '')).join(' ')
  if (LANG === 'ja') console.log('\nCHECK JA OPEN: untaught 元気 / あなた / 私 / 考える in any proven frame: ' + (['元気', 'あなた', '私', '考える'].filter(w => !S.vocab.some(x => (taught.has(x.id) || idSet.has(x.id)) && x.japanese === w) && frames.includes(w)).join(', ') || 'none'))
}
console.log('\nplanning time ' + (Date.now() - t0) + ' ms (no model call)')
